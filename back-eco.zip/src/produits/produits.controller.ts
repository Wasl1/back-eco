import { Controller, Post, Body, UseInterceptors, UploadedFiles, Get, Param } from "@nestjs/common";
import { ProduitsService } from "./produits.service";
import { ProduitsDto } from "./dto/produits.dto";
import { FilesInterceptor } from "@nestjs/platform-express";
import { diskStorage } from 'multer';
import { editFileName, imageFileFilter } from "src/users/file-upload.utils";

@Controller("produits")
export class ProduitsController {
  constructor(private produitsService: ProduitsService) {}

  @Get()
    public async getAllProduits() {
        const produits = await this.produitsService.findAll();
        return { produits, total: produits.length};
    }

    @Get('find')
    public async findOneProduit(@Body() body) {
        const queryCondition = body;
        const produits = await this.produitsService.findOne(queryCondition);
        return produits;
    }

    @Get('/:id')
    public async getUser(@Param() param){
        const produits = await this.produitsService.findById(param.id);
        return produits;
    }

  @Post()
  @UseInterceptors(
    FilesInterceptor("images", 3, {
      storage: diskStorage({
        destination: "./uploads/produits",
        filename: editFileName,
      }),
      fileFilter: imageFileFilter,
    })
  )

  async create(@Body() addProduitsDto: ProduitsDto, @UploadedFiles() files) {
    const response = [];
    files.forEach((file) => {
    response.push(file.filename);
    });
    addProduitsDto.images = response;    

    let data = {};
    let detail_fabrication = {};
    let detail_physique = {};
    let prix = {};

    detail_fabrication["numero_model"] = addProduitsDto.numero_model;
    detail_fabrication["date_sortie"] = addProduitsDto.date_sortie;

    detail_physique["poids"] = addProduitsDto.poids;
    detail_physique["longueur"] = addProduitsDto.longueur;
    detail_physique["largeur"] = addProduitsDto.largeur;
    detail_physique["taille"] = addProduitsDto.taille;
    detail_physique["couleur"] = addProduitsDto.couleur;
    
    prix["prix"] = addProduitsDto.prix;
    prix["prix_promotion"] = addProduitsDto.prix_promotion;

    data["titre"] = addProduitsDto.titre;
    data["description"] = addProduitsDto.description;
    data["categorie"] = addProduitsDto.categorie;
    data["quantite"] = addProduitsDto.quantite;
    data["vote"] = addProduitsDto.vote;
    data["images"] = addProduitsDto.images;
    data["detail_fabrication"] = detail_fabrication;
    data["detail_physique"] = detail_physique;
    data["prix"] = prix;

    return await this.produitsService.create(data);
  }
}
