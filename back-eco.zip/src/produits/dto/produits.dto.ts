export class  ProduitsDto {
    readonly titre: string;
    readonly description: string;
    readonly categorie: string;
    readonly quantite: number;
    readonly vote: number;
     images: any;

    readonly numero_model: string;
    readonly date_sortie: string;
    readonly poids: number;
    readonly longueur: number;
    readonly largeur: number;
    readonly taille: string;
    readonly couleur: string;
    readonly prix: number;
    readonly prix_promotion: number;

}