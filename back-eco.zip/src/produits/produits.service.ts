import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ProduitsInterface } from './interface/produits.interface';

@Injectable()
export class ProduitsService {
    constructor(@InjectModel('Produits') private produitsModel: Model<ProduitsInterface>) {}

    async findOne(options: object): Promise<ProduitsInterface> {
        return await this.produitsModel.findOne(options).exec();
    }

    async findAll(): Promise<ProduitsInterface[]> {
        return await this.produitsModel.find().exec();
    }

    async findById(ID: number): Promise<ProduitsInterface> {
        return await this.produitsModel.findById(ID).exec();
    }

    async create(produitsInterface: any) {
        const createdTodo = new this.produitsModel(produitsInterface);
        return await createdTodo.save();  
    }
}
