export interface Users {
    email: string
}