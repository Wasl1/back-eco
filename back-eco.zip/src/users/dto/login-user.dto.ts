export class LoginUserDto {
    readonly username: string;
    readonly password: string;
}